package com.example.demo2


import android.nfc.Tag
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.GsonBuilder
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.plugins.RxJavaPlugins.onError
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.rc_layout.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory


class MainActivity : AppCompatActivity(),MyAdaptor.Listener{
    lateinit var iv1: ImageView
    lateinit var iv2: ImageView
  private var BASE_URL = "https://www.freetogame.com/api/"
   // private var BASE_URL = "https://api.nomics.com/v1/"
   // val API_KEY = "fb88d9606dmshedbdb85e2e5cd0bp1a79f7jsn0e13052e0b87"
    private var compositeDisposable: CompositeDisposable? = null
    private  var myAdapter: MyAdaptor? = null
    private  var list: ArrayList<GameDetails>? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerview.layoutManager = LinearLayoutManager(this)
        //recyclerview.adapter =MyAdaptor()

        fetchJson()

       setSupportActionBar(toolbar)
        iv1 = findViewById(R.id.iv1)
        iv2 = findViewById(R.id.iv2)
        compositeDisposable = CompositeDisposable()

        iv1.setOnClickListener {
            val popupMenu: PopupMenu = PopupMenu(this,iv1)
            popupMenu.menuInflater.inflate(R.menu.option_filter,popupMenu.menu)
        popupMenu.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
            when(item.itemId){
                R.id.category ->{}


                R.id.platform ->{}

            }
            true
        })
            popupMenu.show()
        }

        iv2.setOnClickListener {
            val popupMenu: PopupMenu = PopupMenu(this,iv2)
            popupMenu.menuInflater.inflate(R.menu.option_sort,popupMenu.menu)
            popupMenu.setOnMenuItemClickListener(PopupMenu.OnMenuItemClickListener { item ->
                when(item.itemId){
                    R.id.releaseDate ->{}


                    R.id.Alphabetical ->{}

                    R.id.relevance ->{}

                }
                true
            })
            popupMenu.show()
        }




}

    private fun fetchJson() {

        // val interceptor: HttpLoggingInterceptor = HttpLoggingInterceptor()
         //interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
         //val client = OkHttpClient.Builder()
           //  .addInterceptor(interceptor).build()
        // val gson = GsonBuilder().setLenient().create()

         val requestRetrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
             .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build().create(APIService::class.java)

         compositeDisposable?.add(requestRetrofit.getGameList()
             .observeOn(AndroidSchedulers.mainThread())
             .subscribeOn(Schedulers.io()).subscribe(this::handleResponse))
         Toast.makeText(this,requestRetrofit.toString(),Toast.LENGTH_LONG).show()







    }
    private fun handleResponse(gameList: List<GameDetails>) {


        list =ArrayList(gameList)
         if(list!=null)
         {
             myAdapter= MyAdaptor(list!!,this)
             recyclerview.adapter = myAdapter
         }

         else
             Toast.makeText(this,"Error",Toast.LENGTH_LONG).show()



    }

    override fun onDestroy() {
        super.onDestroy()
        compositeDisposable?.clear()
    }






}


