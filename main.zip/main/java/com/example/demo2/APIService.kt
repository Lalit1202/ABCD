package com.example.demo2

import io.reactivex.Observable
import retrofit2.http.GET


interface APIService {

    @GET("games")
    fun getGameList(): Observable<List<GameDetails>>
}