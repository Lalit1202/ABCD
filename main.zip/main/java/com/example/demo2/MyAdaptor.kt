package com.example.demo2


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.rc_layout.view.*

 class MyAdaptor(private val gameList:ArrayList<GameDetails>, private  val listener: Listener):
     RecyclerView.Adapter<MyAdaptor.ViewHolder>() {


     interface Listener{


     }

     class ViewHolder(view: View): RecyclerView.ViewHolder(view) {

         fun bind(data: GameDetails)
         {

             itemView.gamename.text = data.title
             itemView.gameCatogery.text = data.genre
             itemView.gameDescription.text = data.short_description
         }

     }

     override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
         val view  = LayoutInflater.from(parent.context).inflate(R.layout.rc_layout,parent,false)
         return ViewHolder(view)

     }

     override fun getItemCount(): Int {
         return gameList.size
          }

     override fun onBindViewHolder(holder: ViewHolder, position: Int) {
         holder.bind(gameList[position])
     }


 }


